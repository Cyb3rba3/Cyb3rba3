### 

#### How to make Skills Gif 



1. Use the style 1/2 codes (html, css, js)
2. Download required SVG logos and keep in icons folder
3. Run index file, if needed adjust radius of circle in style 1
4. Download ScreenToGif Software
5. Record screen and save as GIF
6. For better quality with lesser file size follow below tip :
* &#x09;Keep animation smaller on screen
* &#x20;    Experiment b/w speed vs FPS for clear view and less size
* &#x20;    previous was record at 0.5 speed , 45 FPS and 22 files

