const icons = [
  'Arch.svg','aws.svg','Azure.svg','Bash.svg','git.svg','C.svg','Cpp.svg',
  'docker.svg','ElasticStack.svg','Javascript.svg','Kali.svg','Linux.svg',
  'MySQL.svg','nmap.svg','powershell.svg','Python.svg','Github.svg',
  'Splunk.svg','Suricata.svg','wazuh.svg','Windows.svg','wireshark.svg'
];

function init() {
  const container = document.getElementById("icons-container");

  const path = document
    .getElementById("motion-path")
    .getAttribute("d")
    .replace(/\n/g, " ")
    .replace(/\s+/g, " ");

  const duration = 60;

  const fullIcons = [...icons];

  fullIcons.forEach((name, i) => {
    const el = document.createElement("div");
    el.className = "icon";

    const pathValue = `path("${path}")`;

    el.style.offsetPath = pathValue;
    el.style.webkitOffsetPath = pathValue;

    const delay = (i / fullIcons.length) * duration;
    el.style.animationDelay = `-${delay}s`;

    el.innerHTML = `
      <div class="inner">
        <img src="icons/${name}" />
        
      </div>
    `;

    container.appendChild(el);
  });

  // 🔥 DEPTH + EDGE FADE ENGINE
  function updateDepth() {
    const els = document.querySelectorAll(".icon");
    const containerRect = document.querySelector(".box").getBoundingClientRect();

    els.forEach(el => {
      const style = getComputedStyle(el);
      const dist = parseFloat(style.offsetDistance) || 0;

      let t = dist / 100;

      // 🔥 your depth logic (unchanged)
      const FRONT_SHIFT = 0.15;
      let adjusted = (FRONT_SHIFT - t + 1) % 1;

      let depth = Math.sin(adjusted * Math.PI);
      depth = Math.max(0, depth);

      const scale = 0.75 + depth * 0.2;
      const z = Math.floor(depth * 100);

      // 🔥 EDGE FADE (REAL FIX)
      const rect = el.getBoundingClientRect();

      const leftEdge = containerRect.left;
      const rightEdge = containerRect.right;

      const fadeZone = 60; // adjust if needed

      let edgeFade = 1;

      // fade in from LEFT
      if (rect.left < leftEdge + fadeZone) {
        edgeFade = (rect.left - leftEdge) / fadeZone;
      }

      // fade out at RIGHT
      if (rect.right > rightEdge - fadeZone + 10) {
        edgeFade = (rightEdge - rect.right) / fadeZone;
      }

      edgeFade = Math.max(0, Math.min(1, edgeFade));

      const opacity = (0.50 + depth * 0.55) * edgeFade;

      el.style.transform = `translate(-50%, -50%) scale(${scale})`;
      el.style.opacity = opacity;
      el.style.zIndex = z;
    });

    requestAnimationFrame(updateDepth);
  }

  requestAnimationFrame(updateDepth);
}

document.addEventListener("DOMContentLoaded", init);