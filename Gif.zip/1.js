const icons = [
  { name: 'Arch.svg' },
  { name: 'aws.svg' },
  { name: 'Azure.svg' },
  { name: 'Bash.svg' },
  { name: 'git.svg' },
  { name: 'C.svg' },
  { name: 'Cpp.svg' },
  { name: 'docker.svg' },
  { name: 'ElasticStack.svg' },
  { name: 'Javascript.svg' },
  { name: 'Kali.svg' },
  { name: 'Linux.svg' },
  { name: 'MySQL.svg' },
  { name: 'nmap.svg' },
  { name: 'powershell.svg' },
  { name: 'Python.svg' },
  { name: 'Github.svg' },
  { name: 'Splunk.svg' },
  { name: 'Suricata.svg' },
  { name: 'wazuh.svg' },
  { name: 'Windows.svg' },
  { name: 'wireshark.svg' }
];

const radius = 250;
let rotation = 0;

function init() {
  const container = document.getElementById("icons-container");

  icons.forEach((icon, i) => {
    const el = document.createElement("div");
    el.className = "icon";
    el.dataset.index = i;

    // 🔥 if icons fail, fallback visible
    el.style.backgroundImage = `url(icons/${icon.name})`;
    el.style.backgroundColor = "rgba(255,255,255,0.1)";

    container.appendChild(el);
  });

  animate();
}

function animate() {
  const container = document.getElementById("icons-container");
  rotation += 0.5;

  container.style.transform = `rotateY(${rotation}deg)`;

  const elements = container.querySelectorAll(".icon");

  elements.forEach((el, i) => {
    const baseAngle = (i / elements.length) * 360;
    const currentAngle = (baseAngle + rotation) % 360;

    // position
    el.style.transform = `rotateY(${baseAngle}deg) translateZ(${radius}px)`;

    // brightness zones
    let bright = 0.8;
    let opacity = 0.04;

    if (currentAngle <= 60 || currentAngle >= 300) {
      bright = 1;
      opacity = 1;
    }

    el.style.opacity = opacity;
    el.style.filter = `brightness(${bright})`;
  });

  requestAnimationFrame(animate);
}

document.addEventListener("DOMContentLoaded", init);